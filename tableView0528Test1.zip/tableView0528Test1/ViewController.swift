//
//  ViewController.swift
//  tableView0528Test1
//
//  Created by 홍석평 on 5/28/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

